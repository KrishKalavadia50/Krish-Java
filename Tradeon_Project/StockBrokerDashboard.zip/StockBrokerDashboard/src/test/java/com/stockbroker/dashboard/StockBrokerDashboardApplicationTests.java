package com.stockbroker.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockBrokerDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
