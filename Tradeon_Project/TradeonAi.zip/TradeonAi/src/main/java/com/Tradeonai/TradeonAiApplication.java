package com.Tradeonai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeonAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeonAiApplication.class, args);
	}

}
